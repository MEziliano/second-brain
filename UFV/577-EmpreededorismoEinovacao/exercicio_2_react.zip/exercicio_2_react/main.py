# react_agent.py
"""
Script ReAct Agent para Fins Educacionais

Este script demonstra o padrão de prompting ReAct (Raciocínio + Ação)
usando a API da OpenAI. Foi projetado para ser claro e educacional para
estudantes aprendendo sobre agentes de IA e engenharia de prompts.
"""

import re
import yaml
from pathlib import Path
from typing import Any, Dict, Optional

from openai import OpenAI
from pydantic import BaseModel, Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich.markdown import Markdown
from tavily import TavilyClient


# ============================================================================
# Configurações e Settings
# ============================================================================

class Settings(BaseSettings):
    """
    Configurações da aplicação carregadas de variáveis de ambiente.

    Usa Pydantic Settings para carregar configuração do arquivo .env.
    Esta é uma boa prática para manipular dados sensíveis como API keys.
    """
    openai_api_key: SecretStr = Field(
        default=SecretStr(""),
        description="Chave da API OpenAI para autenticação"
    )
    openai_model: str = Field(
        default="gpt-4.1",
        description="Modelo OpenAI a ser usado para o agente"
    )
    tavily_api_key: SecretStr = Field(
        default=SecretStr(""),
        description="Chave da API Tavily para buscas web"
    )

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )


# ============================================================================
# Modelos Pydantic para Validação de Dados
# ============================================================================

class ToolAction(BaseModel):
    """
    Representa uma ação de ferramenta parseada da resposta do agente.

    Atributos:
        tool_name: Nome da ferramenta a ser executada
        arguments: Argumentos a serem passados para a ferramenta
    """
    tool_name: str = Field(..., description="Nome da ferramenta a executar")
    arguments: str = Field(..., description="Argumentos para a ferramenta")


class DepartmentData(BaseModel):
    """
    Representa dados de um único departamento universitário.

    Este modelo fornece validação para os dados universitários carregados do YAML.
    """
    matriculas: int
    orcamento: float
    publicacoes: int
    docentes: int
    mestrandos: int
    doutorandos: int
    taxa_aprovacao: float
    area_pesquisa_principal: str


# ============================================================================
# Classe do Agente ReAct
# ============================================================================

class ReActAgent:
    """
    Implementação do Agente ReAct (Reasoning + Acting).

    Este agente usa uma abordagem de raciocínio encadeado (chain-of-thought)
    combinada com execução de ferramentas para responder perguntas sobre
    dados universitários.
    """

    def __init__(self, api_key: str, tavily_api_key: str, console: Console, model_name: str = "gpt-4.1"):
        """
        Inicializa o Agente ReAct.

        Args:
            api_key: Chave da API OpenAI
            tavily_api_key: Chave da API Tavily para buscas web
            console: Console Rich para saída formatada
        """
        self.client = OpenAI(api_key=api_key)
        self.tavily_client = TavilyClient(api_key=tavily_api_key)
        self.console = console
        self.dados_universidade = self._carregar_dados()
        self.model_name = model_name

    def _carregar_dados(self) -> Dict[str, Any]:
        """
        Carrega dados universitários estruturados do arquivo YAML.

        Returns:
            Dicionário contendo dados dos departamentos universitários
        """
        data_file = Path(__file__).parent / "university_data.yaml"

        try:
            with open(data_file, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)
                self.console.print(
                    "[green]✓[/green] Dados universitários carregados com sucesso",
                    style="dim"
                )
                return data
        except FileNotFoundError:
            self.console.print(
                f"[red]✗[/red] Erro: {data_file} não encontrado",
                style="bold red"
            )
            raise
        except yaml.YAMLError as e:
            self.console.print(
                f"[red]✗[/red] Erro ao processar YAML: {e}",
                style="bold red"
            )
            raise

    def ferramenta_busca_web(self, query: str) -> str:
        """
        Ferramenta 1: Busca web usando a API Tavily.

        Esta ferramenta permite ao agente buscar informações na web quando
        a resposta não pode ser encontrada nos dados universitários locais.

        Args:
            query: String de consulta de busca

        Returns:
            Resultado da busca como string
        """
        try:
            # Usa Tavily para busca web
            response = self.tavily_client.search(query, max_results=3)

            # Extrai resultados relevantes
            if response and "results" in response and response["results"]:
                # Combina os primeiros resultados
                results_text = []
                for i, result in enumerate(response["results"][:3], 1):
                    title = result.get("title", "")
                    content = result.get("content", "")
                    if title or content:
                        results_text.append(f"{i}. {title}\n{content}")

                if results_text:
                    return "\n\n".join(results_text)

            return f"A busca por '{query}' não retornou resultados. Tente reformular a pergunta."

        except Exception as e:
            return f"Erro ao acessar busca web (Tavily): {str(e)}"

    def ferramenta_python_eval(self, codigo: str) -> str:
        """
        Ferramenta 2: Executa código Python para cálculos e manipulação de dados.

        Esta ferramenta fornece um sandbox seguro para executar expressões Python.
        O código tem acesso aos dados universitários através da variável 'dados'
        e um conjunto limitado de funções built-in seguras.

        Args:
            codigo: String com código Python para executar

        Returns:
            Resultado da execução do código como string

        Exemplo:
            >>> ferramenta_python_eval("dados['departamentos']['Engenharia']['matriculas']")
            "3520"
        """
        try:
            # Contexto de execução seguro com dados disponíveis
            contexto = {
                "dados": self.dados_universidade,
                "__builtins__": {
                    "sum": sum,
                    "len": len,
                    "round": round,
                    "max": max,
                    "min": min,
                    "sorted": sorted,
                    "list": list,
                    "dict": dict,
                    "str": str,
                    "int": int,
                    "float": float,
                    "print": print,
                },
            }

            resultado = eval(codigo, contexto)
            return str(resultado)

        except SyntaxError as e:
            return f"Erro de sintaxe: {str(e)}"
        except NameError as e:
            return f"Erro: variável ou função não definida - {str(e)}"
        except KeyError as e:
            return f"Erro: chave não encontrada nos dados - {str(e)}"
        except Exception as e:
            return f"Erro ao executar código: {str(e)}"

    def _parse_acao(self, acao_texto: str) -> Optional[ToolAction]:
        """
        Faz o parsing de uma ação da resposta do agente.

        Formato esperado: Action: ToolName[argumentos] ou Action: ToolName

        Este parser é robusto e aceita múltiplos formatos:
        - Action: ToolName[argumentos]
        - Action: ToolName
        - Action:ToolName[argumentos] (sem espaço)
        - Com ou sem aspas nos argumentos

        Args:
            acao_texto: Texto contendo a ação

        Returns:
            Objeto ToolAction se o parsing for bem-sucedido, None caso contrário
        """
        # Primeiro tenta encontrar Action: ToolName
        match_action = re.search(
            r"Action:\s*(\w+)",
            acao_texto,
            re.IGNORECASE
        )

        if not match_action:
            self.console.print(
                "[dim]✗ Nenhum padrão 'Action:' encontrado[/dim]",
                style="dim red"
            )
            return None

        tool_name = match_action.group(1)

        # Agora procura por argumentos em colchetes APÓS o nome da tool
        # Usa contagem de colchetes para lidar com [] aninhados
        rest_of_text = acao_texto[match_action.end():]

        # Remove espaços iniciais
        rest_of_text = rest_of_text.lstrip()

        args = ""
        if rest_of_text and rest_of_text[0] == '[':
            # Encontra o ] de fechamento correto usando contagem de colchetes
            bracket_count = 0
            end_idx = -1

            for i, char in enumerate(rest_of_text):
                if char == '[':
                    bracket_count += 1
                elif char == ']':
                    bracket_count -= 1
                    if bracket_count == 0:
                        end_idx = i
                        break

            if end_idx != -1:
                args = rest_of_text[1:end_idx]  # Pega conteúdo entre [ e ]

        # Limpeza robusta dos argumentos
        args_cleaned = args.strip()

        # Remove aspas externas (duplas ou simples) recursivamente
        if args_cleaned:
            while args_cleaned and args_cleaned[0] in ('"', "'"):
                args_cleaned = args_cleaned[1:]
            while args_cleaned and args_cleaned[-1] in ('"', "'"):
                args_cleaned = args_cleaned[:-1]
            # Remove colchetes extras no final
            args_cleaned = args_cleaned.rstrip(']')
            # Remove espaços novamente após limpeza
            args_cleaned = args_cleaned.strip()

        return ToolAction(tool_name=tool_name, arguments=args_cleaned)

    def executar_acao(self, acao_texto: str) -> str:
        """
        Faz o parsing e executa uma ação de ferramenta.

        Args:
            acao_texto: Texto contendo a ação a ser executada

        Returns:
            Resultado da execução da ferramenta
        """
        action = self._parse_acao(acao_texto)

        if not action:
            return "Erro: formato de ação inválido. Use: Action: ToolName[argumentos]"

        # Normaliza nome da tool (case-insensitive)
        tool_name_lower = action.tool_name.lower()

        # BuscaWeb
        if tool_name_lower == "buscaweb":
            if not action.arguments:
                return "Erro: BuscaWeb requer argumentos. Exemplo: BuscaWeb[ranking universidades 2024]"
            return self.ferramenta_busca_web(action.arguments)

        # PythonEval
        elif tool_name_lower == "pythoneval":
            if not action.arguments:
                return "Erro: PythonEval requer código Python. Exemplo: PythonEval[dados['departamentos']]"
            return self.ferramenta_python_eval(action.arguments)

        # Tool desconhecida
        else:
            return f"Erro: Tool desconhecida '{action.tool_name}'. Tools disponíveis: BuscaWeb, PythonEval"

    def executar_react(self, pergunta: str, max_iteracoes: int = 5) -> str:
        """
        Executa o loop de raciocínio ReAct.

        Este é o método principal que implementa o padrão ReAct:
        1. Pensar sobre o que fazer (Thought)
        2. Executar uma ação usando uma ferramenta (Action)
        3. Observar o resultado (Observation)
        4. Repetir até encontrar a resposta

        Args:
            pergunta: Pergunta a ser respondida
            max_iteracoes: Número máximo de iterações

        Returns:
            Resposta final como string
        """

        # Prompt do sistema seguindo princípios do paper ReAct
        prompt_sistema = """Você é um assistente inteligente que responde perguntas sobre dados universitários usando o padrão ReAct (Reasoning + Acting).

ESTRUTURA DOS DADOS DISPONÍVEIS:
A variável 'dados' contém:
{
  'ano': 2024,
  'departamentos': {
    'Engenharia': {'matriculas': 3520, 'orcamento': 850000, 'publicacoes': 45, 'docentes': 87, ...},
    'Ciencias': {'matriculas': 2890, 'orcamento': 620000, 'publicacoes': 38, 'docentes': 72, ...},
    'Artes': {'matriculas': 1450, 'orcamento': 380000, 'publicacoes': 12, 'docentes': 45, ...},
    'Medicina': {'matriculas': 2150, 'orcamento': 1200000, 'publicacoes': 67, 'docentes': 95, ...},
    'Direito': {'matriculas': 1980, 'orcamento': 420000, 'publicacoes': 28, 'docentes': 58, ...}
  },
  'estatisticas_gerais': {'total_alunos': 11990, 'total_docentes': 357, ...}
}

FERRAMENTAS DISPONÍVEIS:

1. BuscaWeb[query]
   - Descrição: Busca informações na web usando DuckDuckGo
   - Quando usar: Para buscar informações gerais, rankings, notícias ou fatos externos
   - Input: String com a consulta de busca - NÃO use aspas!
   - Output: Texto com o resultado da busca ou mensagem de erro
   - EXEMPLOS CORRETOS:
     ✓ BuscaWeb[ranking universidades brasileiras 2024]
     ✓ BuscaWeb[inteligencia artificial aplicacoes]
   - EXEMPLOS ERRADOS:
     ✗ BuscaWeb["ranking universidades brasileiras 2024"]
     ✗ BuscaWeb['inteligencia artificial']

2. PythonEval[código]
   - Descrição: Executa código Python para cálculos e análise de dados
   - Quando usar: Para calcular estatísticas, comparar valores, ou processar dados da universidade
   - Input: Expressão Python válida. Você tem acesso a:
     * Variável 'dados': dicionário com dados universitários
     * Funções: sum, len, round, max, min, sorted, list, dict, str, int, float
   - Output: Resultado da expressão ou mensagem de erro

   EXEMPLOS CORRETOS de PythonEval:
   * Acessar um campo: dados['departamentos']['Engenharia']['matriculas']
   * Somar valores: sum([dados['departamentos'][d]['publicacoes'] for d in dados['departamentos']])
   * Calcular média: dados['departamentos']['Medicina']['orcamento'] / dados['departamentos']['Medicina']['matriculas']
   * Criar dicionário: {d: dados['departamentos'][d]['publicacoes'] / dados['departamentos'][d]['matriculas'] for d in dados['departamentos']}
   * Encontrar máximo: max(dados['departamentos'].items(), key=lambda x: x[1]['publicacoes'])

FORMATO DE RESPOSTA ReAct:

Você DEVE seguir este formato EXATAMENTE - NÃO DESVIE DESTE FORMATO:

Thought: [seu raciocínio aqui]
Action: ToolName[argumentos aqui - SEMPRE inclua os colchetes com os argumentos!]

ATENÇÃO:
- A linha Action DEVE ter o formato: Action: ToolName[argumentos]
- Os colchetes [] são OBRIGATÓRIOS
- Nunca escreva apenas "Action: ToolName" sem os argumentos entre colchetes

EXEMPLOS DO FORMATO CORRETO:
✓ Action: BuscaWeb[ranking universidades brasileiras 2024]
✓ Action: PythonEval[dados['departamentos']['Engenharia']['matriculas']]

EXEMPLOS DO FORMATO ERRADO:
✗ Action: BuscaWeb (FALTAM OS COLCHETES E ARGUMENTOS!)
✗ Action: BuscaWeb["ranking"] (ASPAS DESNECESSÁRIAS)

Após sua ação, o sistema irá inserir:
Observation: [resultado da ferramenta]

Continue Thought/Action/Observation até ter informação suficiente.

Quando pronto, finalize com:
Thought: Tenho informação suficiente para responder a pergunta
Answer: [sua resposta final completa e detalhada]

REGRAS CRÍTICAS:
- SEMPRE inclua colchetes [] com argumentos após o nome da tool
- Use apenas UMA ferramenta por vez
- Seja preciso ao escrever código Python em PythonEval
"""

        historico = [
            {"role": "system", "content": prompt_sistema},
            {"role": "user", "content": f"Pergunta: {pergunta}"},
        ]

        for i in range(max_iteracoes):
            # Display iteration header
            self.console.print()
            self.console.rule(
                f"[bold cyan]Iteração {i + 1}/{max_iteracoes}[/bold cyan]",
                style="cyan"
            )
            self.console.print()

            # Generate next thought/action
            response = self.client.chat.completions.create(
                model=self.model_name,
                messages=historico,
                stop=["Observation:"],
                temperature=0,
            )

            resposta = response.choices[0].message.content

            # Display the agent's reasoning
            self.console.print(Panel(
                resposta,
                title="[bold yellow]🤔 Agent Reasoning[/bold yellow]",
                border_style="yellow",
                padding=(1, 2)
            ))

            # Check if final answer is reached
            if "Answer:" in resposta:
                match = re.search(r"Answer:\s*(.*)", resposta, re.DOTALL)
                final_answer = match.group(1).strip() if match else resposta

                self.console.print()
                self.console.print(Panel(
                    Markdown(final_answer),
                    title="[bold green]✓ Final Answer[/bold green]",
                    border_style="green",
                    padding=(1, 2)
                ))

                return final_answer

            # Execute action and get observation
            observacao = self.executar_acao(resposta)

            # Observacao sempre retorna string, mas pode começar com "Erro:"
            if observacao.startswith("Erro:"):
                # Se é erro, exibe em vermelho e continua
                self.console.print()
                self.console.print(Panel(
                    observacao,
                    title="[bold red]⚠ Erro na Ação[/bold red]",
                    border_style="red",
                    padding=(1, 2)
                ))
                # Adiciona ao histórico para o agente tentar novamente
                obs_texto = f"Observation: {observacao}"
                historico.append({"role": "assistant", "content": resposta})
                historico.append({"role": "user", "content": obs_texto})
            else:
                # Display observation normal
                self.console.print()
                self.console.print(Panel(
                    observacao,
                    title="[bold blue]👁 Observation[/bold blue]",
                    border_style="blue",
                    padding=(1, 2)
                ))

                # Add to history
                obs_texto = f"Observation: {observacao}"
                historico.append({"role": "assistant", "content": resposta})
                historico.append({"role": "user", "content": obs_texto})

        # Max iterations reached
        limit_msg = "Limite de iterações atingido sem resposta completa"
        self.console.print(f"\n[yellow]⚠ {limit_msg}[/yellow]")
        return limit_msg


# ============================================================================
# Main Function - Interactive Q&A Loop
# ============================================================================

def main():
    """
    Função principal com loop interativo de perguntas e respostas.

    Esta função cria uma interface de linha de comando onde estudantes podem
    fazer perguntas e ver o processo de raciocínio ReAct em ação.
    """
    console = Console()

    # Exibe banner de boas-vindas
    console.print()
    console.print(Panel.fit(
        "[bold cyan]Agente ReAct - Demo Interativo[/bold cyan]\n\n"
        "Este agente usa o padrão ReAct (Raciocínio + Ação) para responder\n"
        "perguntas sobre dados universitários combinando raciocínio com uso de ferramentas.",
        border_style="cyan",
        padding=(1, 2)
    ))
    console.print()

    # Carrega configurações
    settings = Settings()
    try:
        console.print("[green]✓[/green] Configurações carregadas com sucesso\n", style="dim")
    except Exception as e:
        console.print(
            f"[red]✗ Erro ao carregar configurações: {e}[/red]\n"
            "[yellow]Certifique-se de ter um arquivo .env com OPENAI_API_KEY[/yellow]",
            style="bold"
        )
        return

    # Inicializa o agente
    try:
        agent = ReActAgent(
            api_key=settings.openai_api_key.get_secret_value(),
            tavily_api_key=settings.tavily_api_key.get_secret_value(),
            console=console
        )
    except Exception as e:
        console.print(f"[red]✗ Erro ao inicializar agente: {e}[/red]", style="bold")
        return

    # Mostra perguntas de exemplo
    console.print(Panel(
        "[bold]Exemplos de perguntas que você pode fazer:[/bold]\n\n"
        "• Qual departamento tem maior taxa de publicações por aluno?\n"
        "• Qual a média de orçamento per capita dos departamentos?\n"
        "• Quantos docentes existem no total?\n"
        "• Busque informações sobre as áreas de pesquisa em destaque da UFV, MG, Brasil\n"
        "• Compare o orçamento de Medicina com Engenharia\n\n"
        "[dim]Digite 'quit', 'exit' ou 'sair' para encerrar a sessão[/dim]",
        title="[bold magenta]💡 Ajuda[/bold magenta]",
        border_style="magenta"
    ))
    console.print()

    # Loop interativo de perguntas e respostas
    while True:
        console.print()
        console.rule("[bold]Nova Pergunta[/bold]", style="white")
        console.print()

        # Obtém pergunta do usuário
        pergunta = Prompt.ask(
            "[bold cyan]❓ Sua pergunta[/bold cyan]",
            default=""
        ).strip()

        # Verifica comandos de saída
        if pergunta.lower() in ["quit", "exit", "sair", "q", ""]:
            console.print()
            console.print(Panel.fit(
                "[bold cyan]Obrigado por usar o Agente ReAct![/bold cyan]\n"
                "Sessão encerrada.",
                border_style="cyan"
            ))
            console.print()
            break

        # Processa a pergunta
        console.print()
        console.print("=" * 80)
        console.print()

        try:
            resposta = agent.executar_react(pergunta)

        except Exception as e:
            console.print()
            console.print(Panel(
                f"[red]Erro ao processar pergunta: {str(e)}[/red]",
                title="[bold red]✗ Erro[/bold red]",
                border_style="red"
            ))

        console.print()
        console.print("=" * 80)


# ============================================================================
# Entry Point
# ============================================================================

if __name__ == "__main__":
    main()
