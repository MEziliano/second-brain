# Agente ReAct

Este projeto demonstra o padrão **ReAct (Reasoning + Acting)** usando APIs da OpenAI e Tavily. É projetado para fins educacionais, mostrando como agentes de IA combinam raciocínio com uso de ferramentas para responder perguntas complexas.

## 📋 O que é ReAct?

ReAct é um padrão de prompting que combina:
- **Reasoning (Raciocínio)**: O agente pensa sobre o problema
- **Acting (Ação)**: O agente usa ferramentas para obter informações
- **Observing (Observação)**: O agente analisa os resultados

Este ciclo se repete até que o agente tenha informações suficientes para responder.

## 🚀 Configuração Inicial

### 1. Pré-requisitos

- Python 3.12 ou superior
- Conta OpenAI com API key ([obtenha aqui](https://platform.openai.com/api-keys))
- Conta Tavily com API key ([obtenha aqui](https://app.tavily.com) - grátis 1000 créditos/mês)

### 2. Instalação

```bash
# Navegue até o diretório
cd exercicio_2_react

# Crie um ambiente virtual
python3.12 -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate

# Instale as dependências
pip install -e .
# ou com poetry:
poetry install
```

### 3. Configurar as API Keys

Crie um arquivo `.env` na raiz do projeto (copie do `.env.example`):

```bash
# .env
OPENAI_API_KEY=sua-chave-openai-aqui
TAVILY_API_KEY=sua-chave-tavily-aqui
```

⚠️ **IMPORTANTE**: Nunca commite o arquivo `.env`!

## 📚 Estrutura do Projeto

```
exercicio_2_react/
├── main.py                 # Script principal com o ReAct Agent
├── university_data.yaml    # Dados universitários para consultas
├── .env                    # Configurações (API key) - NÃO COMMITADO
├── .env.example            # Exemplo de configuração
├── README.md               # Este arquivo
└── pyproject.toml          # Dependências do projeto
```

## 🎯 Como Usar

### Executar o Script

```bash
python main.py
```

### Exemplos de Perguntas

O script aceita perguntas em português sobre dados universitários:

1. **Consultas de dados locais:**
   - "Qual departamento tem maior taxa de publicações por aluno?"
   - "Quantos docentes existem no total?"
   - "Compare o orçamento de Medicina com Engenharia"

2. **Buscas na web:**
   - "Busque informações sobre o ranking das universidades brasileiras em 2024"
   - "Qual é a definição de ReAct prompting?"

3. **Cálculos complexos:**
   - "Qual a média de orçamento per capita dos departamentos?"
   - "Qual departamento tem a melhor relação publicações/docentes?"

### Sair do Programa

Digite qualquer um dos seguintes comandos:
- `quit`
- `exit`
- `sair`
- `q`
- Ou simplesmente pressione Enter

## 🛠️ Ferramentas Disponíveis

O agente tem acesso a duas ferramentas:

### 1. BuscaWeb
Busca informações na web usando a API Tavily (ferramenta de busca para IA)
```
Action: BuscaWeb[sua consulta aqui]
```

### 2. PythonEval
Executa código Python para cálculos e análise de dados universitários
```
Action: PythonEval[código Python]
```

## 📖 Componentes Principais

### Settings (Pydantic Settings)
Gerencia configurações do ambiente usando Pydantic Settings:
- Lê a API key do arquivo `.env`
- Valida configurações automaticamente
- Usa `SecretStr` para proteger dados sensíveis

### ReActAgent
Classe principal que implementa o padrão ReAct:
- Carrega dados do YAML
- Gerencia o ciclo Thought/Action/Observation
- Executa ferramentas baseado nas decisões do agente

### Rich Console
Interface de linha de comando colorida e formatada:
- Painéis coloridos para diferentes tipos de informação
- Marcadores visuais para etapas do processo
- Formato Markdown para respostas

## 🐛 Resolução de Problemas

### Erro: API keys não encontradas
- Verifique se o arquivo `.env` existe na raiz do projeto
- Confirme que ambas as variáveis estão definidas: `OPENAI_API_KEY` e `TAVILY_API_KEY`
- Certifique-se de estar no diretório correto

### Erro: "university_data.yaml not found"
- O arquivo deve estar no mesmo diretório que `main.py`
- Verifique o nome do arquivo (case-sensitive)

### Problemas com busca web
- Verifique sua conexão com a internet
- Confirme que sua chave Tavily é válida e tem créditos disponíveis
- Tavily oferece 1000 créditos gratuitos por mês

## 📚 Recursos Adicionais

- [ReAct Paper (Original)](https://arxiv.org/abs/2210.03629)
- [Pydantic Documentation](https://docs.pydantic.dev/)
- [Rich Documentation](https://rich.readthedocs.io/)
- [OpenAI API Documentation](https://platform.openai.com/docs/)
- [Tavily API Documentation](https://docs.tavily.com/)

## 📄 Licença

Este projeto é para fins educacionais. Use livremente para aprender e ensinar!

---

**Desenvolvido para o curso de IA Generativa - Universidade Federal de Viçosa**
