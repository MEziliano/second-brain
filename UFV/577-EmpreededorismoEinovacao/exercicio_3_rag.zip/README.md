# Sistema RAG Simples

Sistema de Retrieval Augmented Generation (RAG) simples e educacional para processar PDFs e fazer perguntas sobre eles usando OpenAI.

## 📚 Sobre

O sistema possui duas fases:

- **Fase Offline**: Processa PDFs, divide em chunks e armazena embeddings
- **Fase Online**: Responde perguntas usando contexto recuperado dos documentos

## 🚀 Instalação

1. Clone o repositório
2. Instale as dependências com Poetry:

```bash
poetry install
```

3. Configure as variáveis de ambiente:

```bash
cp .env.example .env
# Edite o arquivo .env com suas credenciais
```

## 📖 Uso

### Fase Offline: Ingestão de Documentos

Processa PDFs e armazena no banco vetorial persistente:

```bash
poetry run python scripts/offline_ingerir.py pdfs/
```

Este comando:
- Lê todos os PDFs do diretório especificado
- Divide em chunks com overlap
- Gera embeddings usando OpenAI
- Armazena no ChromaDB (pasta `.chroma_db/`)

### Fase Online: Perguntas e Respostas

Faça perguntas sobre os documentos já processados:

```bash
poetry run python scripts/online_perguntar.py
```

Este comando:
- Carrega a base de conhecimento existente
- Permite fazer perguntas interativamente
- Mostra os chunks recuperados (preview de 200 caracteres)
- Gera respostas usando RAG

### Resetar o Banco de Dados

Para recomeçar do zero, simplesmente delete a pasta do banco:

```bash
rm -rf .chroma_db/
```

Depois execute novamente o script offline.

## 🏗️ Estrutura do Projeto

```
rag_simples/
├── __init__.py      # Exportações principais
├── config.py        # Configurações (Pydantic Settings)
├── modelos.py       # Modelos de dados (Pydantic)
└── rag.py           # Sistema RAG principal

scripts/
├── offline_ingerir.py    # Script de ingestão
└── online_perguntar.py   # Script de perguntas

pdfs/                # Coloque seus PDFs aqui
```

## ⚙️ Configuração

Edite o arquivo `.env` para ajustar:

- `OPENAI_API_KEY`: Sua chave da API OpenAI
- `OPENAI_BASE_URL`: URL base (para provedores compatíveis com OpenAI)
- `MODELO_EMBEDDINGS`: Modelo de embeddings (padrão: text-embedding-3-small)
- `MODELO_CHAT`: Modelo de chat (padrão: gpt-4.1)
- `TAMANHO_CHUNK`: Tamanho dos chunks em palavras (padrão: 500)
- `OVERLAP_CHUNK`: Overlap entre chunks (padrão: 50)
- `TOP_K`: Número de chunks recuperados (padrão: 5)

## 🎯 Conceitos Demonstrados

- **Chunking**: Divisão de documentos em pedaços menores
- **Embeddings**: Representação vetorial de texto
- **Vector Database**: Armazenamento e busca por similaridade
- **Retrieval**: Recuperação de contexto relevante
- **Augmented Generation**: Geração de respostas com contexto

