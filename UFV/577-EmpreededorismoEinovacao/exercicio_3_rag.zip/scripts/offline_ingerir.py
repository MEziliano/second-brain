"""Script para ingestão de PDFs (Fase Offline)."""

from pathlib import Path

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from rag_simples import Configuracao, SistemaRAG

app = typer.Typer()
console = Console()


@app.command()
def ingerir(
    diretorio: Path = typer.Argument(
        ...,
        help="Diretório contendo os arquivos PDF",
        exists=True,
        dir_okay=True,
        file_okay=False,
    )
):
    """Processa PDFs e armazena no banco vetorial."""
    console.print("\n[bold cyan]═══ FASE OFFLINE: Ingestão de Documentos ═══[/bold cyan]\n")

    # Carrega configurações
    config = Configuracao()

    # Inicializa sistema RAG
    rag = SistemaRAG(config)

    # Conta PDFs
    pdfs = list(diretorio.glob("*.pdf"))
    if not pdfs:
        console.print(f"[red]✗ Nenhum PDF encontrado em {diretorio}[/red]")
        raise typer.Exit(1)

    console.print(f"[green]✓ Encontrados {len(pdfs)} PDFs[/green]")

    # Processa com progresso
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Processando documentos...", total=None)
        total_chunks = rag.processar_documentos(diretorio)
        progress.update(task, completed=True)

    console.print(f"[green]✓ Processados {total_chunks} chunks[/green]")
    console.print("\n[bold green]✓ Pipeline offline concluído com sucesso![/bold green]\n")


if __name__ == "__main__":
    app()
