"""Script para fazer perguntas (Fase Online)."""

import typer
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich.table import Table

from rag_simples import Configuracao, SistemaRAG

app = typer.Typer()
console = Console()


@app.command()
def perguntar():
    """Interface de perguntas e respostas com RAG."""
    console.print("\n[bold cyan]═══ FASE ONLINE: Perguntas e Respostas ═══[/bold cyan]\n")

    # Carrega configurações
    config = Configuracao()

    # Inicializa RAG e carrega coleção existente
    rag = SistemaRAG(config)

    try:
        console.print("[yellow]Carregando base de conhecimento...[/yellow]")
        rag.carregar_colecao()
        console.print("[green]✓ Base carregada com sucesso[/green]\n")
    except ValueError as e:
        console.print(f"[red]✗ {e}[/red]")
        console.print("[yellow]Execute primeiro: poetry run python scripts/offline_ingerir.py pdfs/[/yellow]\n")
        raise typer.Exit(1)

    # Loop de perguntas
    console.print("[dim]Digite 'sair' para encerrar[/dim]\n")

    while True:
        # Pergunta do usuário
        query = Prompt.ask("[bold blue]Você[/bold blue]")

        if query.lower() in ["sair", "exit", "quit"]:
            console.print("\n[yellow]Encerrando...[/yellow]")
            break

        if not query.strip():
            continue

        # Busca e responde
        try:
            console.print("\n[dim]🔍 Buscando contextos relevantes...[/dim]")
            resposta, contextos = rag.responder(query)

            # Mostra chunks recuperados
            console.print()
            tabela = Table(title="📚 Chunks Recuperados", show_header=True, header_style="bold cyan")
            tabela.add_column("#", style="dim", width=3)
            tabela.add_column("Fonte", style="cyan", width=20)
            tabela.add_column("Preview (200 chars)", style="white", width=60)
            tabela.add_column("Similaridade", justify="right", width=12)

            for idx, ctx in enumerate(contextos, 1):
                preview = ctx.texto[:200].replace("\n", " ")
                if len(ctx.texto) > 200:
                    preview += "..."

                similaridade = f"{(1 - ctx.distancia) * 100:.1f}%"

                tabela.add_row(
                    str(idx),
                    ctx.fonte,
                    preview,
                    similaridade
                )

            console.print(tabela)
            console.print()

            # Mostra resposta
            console.print(
                Panel(
                    resposta,
                    title="[bold green]💬 Assistente[/bold green]",
                    border_style="green",
                )
            )
            console.print()

        except Exception as e:
            console.print(f"[red]✗ Erro: {e}[/red]\n")


if __name__ == "__main__":
    app()
