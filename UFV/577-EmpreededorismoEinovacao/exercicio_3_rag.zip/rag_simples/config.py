"""Configurações do sistema usando Pydantic Settings."""

from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import SecretStr


class Configuracao(BaseSettings):
    """Configurações da aplicação RAG."""

    # OpenAI
    openai_api_key: SecretStr = SecretStr("Use .env pra chave")
    openai_base_url: str = "https://api.openai.com/v1"
    modelo_embeddings: str = "text-embedding-3-small"
    modelo_chat: str = "gpt-4.1"

    # ChromaDB
    nome_colecao: str = "documentos"
    caminho_db: str = ".chroma_db"

    # Chunking
    tamanho_chunk: int = 500
    overlap_chunk: int = 50

    # Retrieval
    top_k: int = 5

    # Geração
    max_tokens: int = 2048

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False
    )
