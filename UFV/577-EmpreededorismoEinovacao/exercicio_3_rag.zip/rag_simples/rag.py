"""Sistema RAG principal."""

from pathlib import Path

import chromadb
from chromadb.config import Settings
from openai import OpenAI
from PyPDF2 import PdfReader

from rag_simples.config import Configuracao
from rag_simples.modelos import Chunk, Contexto, Documento


class SistemaRAG:
    """Sistema RAG para ingestão e consulta de documentos."""

    def __init__(self, config: Configuracao):
        self.config = config
        self.client = OpenAI(
            api_key=config.openai_api_key.get_secret_value(),
            base_url=config.openai_base_url
        )
        self.chroma_client = chromadb.PersistentClient(
            path=config.caminho_db,
            settings=Settings(anonymized_telemetry=False)
        )
        self.colecao = None

    # === FASE OFFLINE: Ingestão ===

    def carregar_pdfs(self, diretorio: Path) -> list[Documento]:
        """Carrega todos os PDFs de um diretório."""
        documentos = []

        for arquivo_pdf in diretorio.glob("*.pdf"):
            with open(arquivo_pdf, "rb") as f:
                leitor = PdfReader(f)
                texto = "".join(pagina.extract_text() for pagina in leitor.pages)
                documentos.append(
                    Documento(nome_arquivo=arquivo_pdf.name, texto=texto)
                )

        return documentos

    def fazer_chunking(self, documentos: list[Documento]) -> list[Chunk]:
        """Divide documentos em chunks com overlap."""
        chunks = []

        for doc in documentos:
            palavras = doc.texto.split()
            tamanho = self.config.tamanho_chunk
            overlap = self.config.overlap_chunk

            for i in range(0, len(palavras), tamanho - overlap):
                texto_chunk = " ".join(palavras[i : i + tamanho])
                chunks.append(
                    Chunk(
                        texto=texto_chunk,
                        fonte=doc.nome_arquivo,
                        chunk_id=len(chunks),
                    )
                )

        return chunks

    def criar_embeddings(self, chunks: list[Chunk]) -> list[Chunk]:
        """Gera embeddings para os chunks."""
        textos = [chunk.texto for chunk in chunks]

        resposta = self.client.embeddings.create(
            model=self.config.modelo_embeddings, input=textos
        )

        for i, embedding_obj in enumerate(resposta.data):
            chunks[i].embedding = embedding_obj.embedding

        return chunks

    def armazenar_no_banco(self, chunks: list[Chunk]) -> None:
        """Armazena chunks no ChromaDB."""
        # Tenta deletar coleção existente se houver
        try:
            self.chroma_client.delete_collection(name=self.config.nome_colecao)
        except Exception:
            pass

        self.colecao = self.chroma_client.create_collection(
            name=self.config.nome_colecao,
            metadata={"description": "Documentos processados"},
        )

        self.colecao.add(
            ids=[f"chunk_{c.chunk_id}" for c in chunks],
            embeddings=[c.embedding for c in chunks],
            documents=[c.texto for c in chunks],
            metadatas=[{"fonte": c.fonte} for c in chunks],
        )

    def carregar_colecao(self) -> None:
        """Carrega coleção existente do banco."""
        try:
            self.colecao = self.chroma_client.get_collection(
                name=self.config.nome_colecao
            )
        except Exception:
            raise ValueError(
                f"Coleção '{self.config.nome_colecao}' não encontrada. "
                "Execute a fase offline primeiro."
            )

    def processar_documentos(self, diretorio: Path) -> int:
        """Pipeline completo de ingestão."""
        documentos = self.carregar_pdfs(diretorio)
        chunks = self.fazer_chunking(documentos)
        chunks_com_embeddings = self.criar_embeddings(chunks)
        self.armazenar_no_banco(chunks_com_embeddings)
        return len(chunks_com_embeddings)

    # === FASE ONLINE: Consulta ===

    def buscar_contexto(self, query: str) -> list[Contexto]:
        """Busca contextos relevantes para a query."""
        if not self.colecao:
            raise ValueError("Nenhuma coleção carregada. Execute a fase offline primeiro.")

        # Gera embedding da query
        query_embedding = self.client.embeddings.create(
            model=self.config.modelo_embeddings, input=[query]
        ).data[0].embedding

        # Busca no ChromaDB
        resultados = self.colecao.query(
            query_embeddings=[query_embedding],
            n_results=self.config.top_k
        )

        # TODO: Opcionalmente, filtrar por distância máxima.
        # Isso é, descartar contextos muito distantes baseado em um limiar

        # Converte para modelo Contexto
        contextos = [
            Contexto(
                texto=resultados["documents"][0][i],
                fonte=resultados["metadatas"][0][i]["fonte"],
                distancia=resultados["distances"][0][i],
            )
            for i in range(len(resultados["documents"][0]))
        ]

        return contextos

    def gerar_resposta(self, query: str, contextos: list[Contexto]) -> str:
        """Gera resposta usando LLM com RAG."""
        # Formata contextos
        contexto_formatado = "\n\n".join(
            f"[Fonte: {ctx.fonte}]\n{ctx.texto}" for ctx in contextos
        )

        # Cria prompt
        prompt = f"""Baseado nos documentos abaixo, responda a pergunta.
Se a informação não estiver nos documentos, diga que não encontrou.

DOCUMENTOS:
{contexto_formatado}

PERGUNTA: {query}

RESPOSTA:"""

        # Chama LLM
        resposta = self.client.chat.completions.create(
            model=self.config.modelo_chat,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=self.config.max_tokens,
        )

        return resposta.choices[0].message.content

    def responder(self, query: str) -> tuple[str, list[Contexto]]:
        """Pipeline completo de consulta."""
        contextos = self.buscar_contexto(query)
        resposta = self.gerar_resposta(query, contextos)
        return resposta, contextos
