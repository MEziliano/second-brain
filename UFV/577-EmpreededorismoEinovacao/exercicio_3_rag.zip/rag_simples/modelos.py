"""Modelos de dados usando Pydantic."""

from pydantic import BaseModel, Field


class Documento(BaseModel):
    """Representa um documento carregado."""

    nome_arquivo: str
    texto: str


class Chunk(BaseModel):
    """Representa um pedaço de texto com embeddings."""

    texto: str
    fonte: str
    chunk_id: int
    embedding: list[float] | None = None


class Contexto(BaseModel):
    """Representa um contexto recuperado da busca."""

    texto: str
    fonte: str
    distancia: float = Field(description="Distância do embedding (menor = mais similar)")
