#!/usr/bin/env python3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

import typer
from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Prompt
from sistema import SistemaMultiAgente

app = typer.Typer(help="Sistema Multi-Agente para Geração de Relatórios")
console = Console()


def exibir_banner():
    """Exibe banner inicial"""
    banner = """
    ╔═══════════════════════════════════════════════════════╗
    ║   Sistema Multi-Agente - Geração de Relatórios       ║
    ║   Universidade Federal de Viçosa                      ║
    ╚═══════════════════════════════════════════════════════╝
    """
    console.print(banner, style="bold cyan")


def exibir_delegacao(agente_origem: str, agente_destino: str, mensagem: str):
    """Exibe delegação de tarefa"""
    emoji_map = {
        "gerente_coordenador": "👔",
        "arquivista_documentos": "📚",
        "verificador_fatos": "🔍",
        "escritor_relatorios": "✍️",
    }

    titulo = f"{emoji_map.get(agente_origem, '🤖')} {agente_origem.replace('_', ' ').title()}"
    conteudo = f"[bold]Delegando para:[/bold] {agente_destino}\n\n"
    msg_truncada = mensagem[:150] + "..." if len(mensagem) > 150 else mensagem
    conteudo += f"[dim]{msg_truncada}[/dim]"

    console.print(
        Panel(conteudo, title=titulo, border_style="cyan", padding=(1, 2))
    )


def exibir_ferramenta(agente: str, ferramenta: str, args: dict):
    """Exibe execução de ferramenta"""
    emoji_map = {
        "buscar_documentos": "📄",
        "buscar_web": "🌐",
        "responder_gerente": "💬",
    }

    titulo = f"{emoji_map.get(ferramenta, '🔧')} {ferramenta.replace('_', ' ').title()}"

    if ferramenta == "buscar_documentos":
        conteudo = f"[yellow]Consulta:[/yellow] {args.get('consulta', 'N/A')}"
    elif ferramenta == "buscar_web":
        conteudo = f"[yellow]Consulta:[/yellow] {args.get('consulta', 'N/A')}"
    elif ferramenta == "responder_gerente":
        msg = args.get("mensagem", "")
        conteudo = f"[green]Resposta:[/green] {msg[:400]}{'...' if len(msg) > 400 else ''}"
    else:
        conteudo = str(args)

    console.print(Panel(conteudo, title=titulo, border_style="yellow", padding=(0, 2)))


def processar_com_feedback(sistema: SistemaMultiAgente, consulta: str) -> str:
    """Processa consulta com feedback visual"""
    console.print("\n[bold green]Processando solicitação...[/bold green]\n")

    class SistemaMonitorado(SistemaMultiAgente):
        def _executar_agente(self, nome_agente: str) -> dict:
            console.print(
                f"\n[bold blue]→[/bold blue] Executando: [cyan]{nome_agente}[/cyan]"
            )
            return super()._executar_agente(nome_agente)

        def _executar_ferramenta(
            self, nome_agente: str, nome_funcao: str, argumentos: dict
        ) -> dict:
            exibir_ferramenta(nome_agente, nome_funcao, argumentos)
            resultado = super()._executar_ferramenta(
                nome_agente, nome_funcao, argumentos
            )

            # Mostra preview dos resultados de busca
            if nome_funcao in ["buscar_documentos", "buscar_web"]:
                conteudo = resultado.get("conteudo", "")
                if conteudo and len(conteudo) > 100:
                    preview = conteudo[:300] + "..." if len(conteudo) > 300 else conteudo
                    console.print(f"[dim]  Resultado: {preview}[/dim]")

            if resultado.get("delegar"):
                exibir_delegacao(
                    nome_agente,
                    resultado["agente_destino"],
                    argumentos.get("mensagem", ""),
                )

            return resultado

    sistema_monitorado = SistemaMonitorado()
    sistema_monitorado.client = sistema.client
    sistema_monitorado.ferramentas = sistema.ferramentas
    sistema_monitorado.agentes = sistema.agentes

    with Progress(
        SpinnerColumn(), TextColumn("[progress.description]{task.description}")
    ) as progress:
        task = progress.add_task("Gerando relatório...", total=None)
        relatorio = sistema_monitorado.processar_consulta(consulta)
        progress.update(task, completed=True)

    return relatorio


@app.command()
def gerar(
    consulta: str = typer.Option(
        None, "--consulta", "-c", help="Consulta para geração do relatório"
    ),
    salvar: bool = typer.Option(
        False, "--salvar", "-s", help="Salvar relatório em arquivo"
    ),
):
    """Gera um relatório baseado na consulta fornecida"""
    exibir_banner()

    if not consulta:
        console.print("\n[bold]Digite sua solicitação:[/bold]")
        consulta = Prompt.ask("Consulta")

    if not consulta.strip():
        console.print("[red]Erro: Consulta não pode estar vazia[/red]")
        raise typer.Exit(1)

    try:
        sistema = SistemaMultiAgente()
        relatorio = processar_com_feedback(sistema, consulta)

        console.print("\n" + "=" * 70)
        console.print("\n[bold green]✓ Relatório Gerado com Sucesso![/bold green]\n")
        console.print("=" * 70 + "\n")

        md = Markdown(relatorio)
        console.print(Panel(md, border_style="green", padding=(1, 2)))

        if salvar:
            arquivo = Path("relatorio.md")
            arquivo.write_text(relatorio, encoding="utf-8")
            console.print(
                f"\n[green]✓ Relatório salvo em: {arquivo.absolute()}[/green]"
            )

    except Exception as e:
        console.print(f"\n[red]Erro ao processar consulta: {str(e)}[/red]")
        raise typer.Exit(1)


@app.command()
def exemplos():
    """Mostra exemplos de consultas"""
    console.print("\n[bold cyan]Exemplos de Consultas:[/bold cyan]\n")

    exemplos = [
        "Gere um relatório sobre o edital de pesquisa em IA de 2024",
        "Crie um resumo do programa de bolsas de extensão",
        "Analise os requisitos para mestrado em Ciência da Computação",
        "Compare prazos e valores dos editais disponíveis",
    ]

    for i, ex in enumerate(exemplos, 1):
        console.print(f"{i}. [green]{ex}[/green]")

    console.print(
        "\n[dim]Use: python scripts/executar.py gerar --consulta 'sua consulta aqui'[/dim]\n"
    )


if __name__ == "__main__":
    app()
