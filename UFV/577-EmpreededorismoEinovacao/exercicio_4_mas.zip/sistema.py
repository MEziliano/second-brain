import json
from openai import OpenAI
from config import settings
from agentes import (
    criar_agente_gerente,
    criar_agente_arquivista,
    criar_agente_verificador,
    criar_agente_escritor,
    obter_ferramentas_para_agente,
)
from ferramentas import GerenciadorFerramentas


class SistemaMultiAgente:
    """Sistema coordenado de múltiplos agentes LLM"""

    def __init__(self):

        self.client = OpenAI(
            api_key=settings.openai_api_key.get_secret_value(),
            base_url=settings.openai_base_url,
        )

        self.ferramentas = GerenciadorFerramentas()

        self.agentes = {
            "gerente_coordenador": criar_agente_gerente(),
            "arquivista_documentos": criar_agente_arquivista(),
            "verificador_fatos": criar_agente_verificador(),
            "escritor_relatorios": criar_agente_escritor(),
        }

        self.historico = []
        self.max_iteracoes = 30
        self.agentes_consultados = set()

    def processar_consulta(self, consulta_usuario: str) -> str:
        """Processa uma consulta do usuário e retorna o relatório"""
        self.historico = []
        self.agentes_consultados = set()

        self.historico.append({"role": "user", "content": consulta_usuario})

        agente_atual = "gerente_coordenador"
        iteracao = 0

        while iteracao < self.max_iteracoes:
            iteracao += 1

            resposta = self._executar_agente(agente_atual)

            if resposta.get("finalizado"):
                return resposta.get("conteudo", "Relatório não gerado.")

            if resposta.get("proximo_agente"):
                agente_atual = resposta["proximo_agente"]
            elif resposta.get("retornar_gerente"):
                agente_atual = "gerente_coordenador"

        return "Sistema atingiu limite de iterações sem concluir."

    def _executar_agente(self, nome_agente: str) -> dict:
        """Executa um agente e retorna resultado"""
        agente = self.agentes[nome_agente]
        ferramentas = obter_ferramentas_para_agente(nome_agente)

        mensagens = [{"role": "system", "content": agente.instrucoes}]

        # Adiciona contexto de progresso para o gerente
        if nome_agente == "gerente_coordenador" and self.historico:
            # Extrai resumos das respostas dos agentes
            respostas_anteriores = [
                msg.get("content", "")[:200]
                for msg in self.historico
                if msg.get("role") == "assistant" and msg.get("content")
            ]

            if self.agentes_consultados or respostas_anteriores:
                contexto = "[CONTEXTO DE PROGRESSO]\n"
                if self.agentes_consultados:
                    contexto += f"Agentes já consultados: {', '.join(self.agentes_consultados)}\n"
                if respostas_anteriores:
                    contexto += f"Últimas {len(respostas_anteriores)} respostas recebidas.\n"
                mensagens.append({"role": "system", "content": contexto})

        mensagens.extend(self.historico)

        resposta = self.client.chat.completions.create(
            model=settings.modelo_llm, messages=mensagens, tools=ferramentas
        )

        mensagem_resposta = resposta.choices[0].message

        if mensagem_resposta.tool_calls:
            return self._processar_tool_calls(
                nome_agente, mensagem_resposta, ferramentas
            )

        conteudo = mensagem_resposta.content or ""
        self.historico.append({"role": "assistant", "content": conteudo})

        if nome_agente == "gerente_coordenador" and not mensagem_resposta.tool_calls:
            return {"finalizado": True, "conteudo": conteudo}

        return {"finalizado": False}

    def _processar_tool_calls(
        self, nome_agente: str, mensagem_resposta, ferramentas: list
    ) -> dict:
        """Processa chamadas de ferramentas"""
        # Identifica tipos de ferramentas
        tem_delegacao = any(
            tc.function.name == "delegar_tarefa"
            for tc in mensagem_resposta.tool_calls
        )
        tem_resposta = any(
            tc.function.name == "responder_gerente"
            for tc in mensagem_resposta.tool_calls
        )

        # Processa delegação/resposta (uma tool por vez)
        if tem_delegacao or tem_resposta:
            tool_call = mensagem_resposta.tool_calls[0]
            nome_funcao = tool_call.function.name
            argumentos = json.loads(tool_call.function.arguments)

            resultado = self._executar_ferramenta(
                nome_agente, nome_funcao, argumentos
            )

            if resultado.get("delegar"):
                agente_destino = resultado['agente_destino']
                self.agentes_consultados.add(agente_destino)
                return {
                    "finalizado": False,
                    "proximo_agente": agente_destino,
                }
            elif resultado.get("responder_gerente"):
                # Adiciona a resposta REAL do agente ao histórico
                resposta_agente = argumentos.get("mensagem", "")
                self.historico.append(
                    {
                        "role": "assistant",
                        "content": resposta_agente,
                    }
                )
                return {"finalizado": False, "retornar_gerente": True}

        # Para ferramentas de busca
        self.historico.append(
            {
                "role": "assistant",
                "content": mensagem_resposta.content or "",
                "tool_calls": [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {
                            "name": tc.function.name,
                            "arguments": tc.function.arguments
                        },
                    }
                    for tc in mensagem_resposta.tool_calls
                ],
            }
        )

        for tool_call in mensagem_resposta.tool_calls:
            nome_funcao = tool_call.function.name
            argumentos = json.loads(tool_call.function.arguments)

            resultado = self._executar_ferramenta(
                nome_agente, nome_funcao, argumentos
            )

            self.historico.append(
                {
                    "role": "tool",
                    "tool_call_id": tool_call.id,
                    "content": resultado["conteudo"],
                }
            )

        return {"finalizado": False}

    def _executar_ferramenta(
        self, nome_agente: str, nome_funcao: str, argumentos: dict
    ) -> dict:
        """Executa uma ferramenta e retorna resultado"""
        if nome_funcao == "delegar_tarefa":
            mensagem = argumentos.get("mensagem", "")
            agente_destino = argumentos.get("agente_destino", "")

            # Mantém consulta original E respostas dos agentes
            consulta_original = next(
                (msg for msg in self.historico if msg.get("role") == "user"),
                None
            )
            # Mantém TODAS respostas assistant (sem tool_calls)
            respostas_agentes = [
                msg for msg in self.historico
                if msg.get("role") == "assistant" and "tool_calls" not in msg
            ]

            self.historico = []
            if consulta_original:
                self.historico.append(consulta_original)

            # Adiciona todas as respostas para contexto completo
            self.historico.extend(respostas_agentes)

            self.historico.append(
                {
                    "role": "user",
                    "content": f"[Tarefa do gerente]: {mensagem}",
                }
            )

            return {
                "conteudo": f"Tarefa delegada para {agente_destino}",
                "delegar": True,
                "agente_destino": agente_destino,
            }

        elif nome_funcao == "responder_gerente":
            mensagem = argumentos.get("mensagem", "")
            return {
                "conteudo": f"Resposta recebida: {mensagem}",
                "responder_gerente": True,
            }

        elif nome_funcao == "buscar_documentos":
            consulta = argumentos.get("consulta", "")
            max_resultados = argumentos.get("max_resultados", 3)
            resultado = self.ferramentas.buscar_documentos(
                consulta, max_resultados
            )
            return {"conteudo": resultado}

        elif nome_funcao == "buscar_web":
            consulta = argumentos.get("consulta", "")
            resultado = self.ferramentas.buscar_web(consulta)
            return {"conteudo": resultado}

        return {"conteudo": "Ferramenta não encontrada"}

    def obter_historico(self) -> list:
        """Retorna histórico de mensagens"""
        return self.historico.copy()
