from pydantic import BaseModel


class ResultadoBusca(BaseModel):
    """Resultado de busca em documentos"""

    texto: str
    arquivo: str
    score: float


class Agente(BaseModel):
    """Definição de um agente"""

    nome: str
    descricao: str
    instrucoes: str
    ferramentas: list[str]
