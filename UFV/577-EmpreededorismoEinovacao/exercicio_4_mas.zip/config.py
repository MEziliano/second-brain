from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import SecretStr


class Settings(BaseSettings):
    """Configurações da aplicação"""

    openai_api_key: SecretStr = SecretStr("Use o .env para configurar")
    openai_base_url: str = "https://api.openai.com/v1"
    tavily_api_key: SecretStr = SecretStr("Use o .env para configurar")
    modelo_llm: str = "gpt-4.1"
    max_tokens_busca: int = 1000
    chunk_size_documentos: int = 500

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")


settings = Settings()
