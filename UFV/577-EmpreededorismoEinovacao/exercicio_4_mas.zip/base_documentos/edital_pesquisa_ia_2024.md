# Edital de Pesquisa em Inteligência Artificial 2024

**Instituição:** Universidade Federal de Viçosa (UFV)
**Programa:** Fomento à Pesquisa em IA
**Número:** EDITAL-IA-2024-001
**Data de Publicação:** 15 de janeiro de 2024

## Objetivo

Apoiar projetos de pesquisa na área de Inteligência Artificial com foco em aplicações para agricultura, saúde pública e educação.

## Recursos Disponíveis

- Valor total do edital: R$ 500.000,00
- Valor máximo por projeto: R$ 50.000,00
- Número de projetos a serem financiados: até 10 projetos
- Duração: 12 meses

## Áreas Temáticas Elegíveis

1. Machine Learning aplicado à agricultura de precisão
2. Processamento de Linguagem Natural para educação
3. Visão computacional para diagnóstico médico
4. Sistemas de recomendação inteligentes
5. IA explicável e ética em sistemas autônomos

## Requisitos

### Coordenador do Projeto
- Ser docente permanente da UFV
- Ter título de doutor há pelo menos 2 anos
- Não ter projeto em atraso com a instituição
- Disponibilidade de pelo menos 10h semanais

### Contrapartida Institucional
- Infraestrutura de laboratório adequada
- Apoio técnico-administrativo
- Recursos computacionais mínimos (GPUs disponíveis)

## Prazos Importantes

- **Submissão de propostas:** até 28 de fevereiro de 2024
- **Divulgação dos resultados:** 15 de março de 2024
- **Início dos projetos:** 1º de abril de 2024

## Documentação Necessária

1. Formulário de proposta preenchido
2. Currículo Lattes atualizado do coordenador
3. Carta de anuência do departamento
4. Plano de trabalho detalhado
5. Orçamento discriminado

## Critérios de Avaliação

- Relevância científica e inovação (peso 3)
- Viabilidade técnica e metodológica (peso 2)
- Qualificação da equipe (peso 2)
- Impacto potencial dos resultados (peso 2)
- Adequação do orçamento (peso 1)

## Contato

**Email:** pesquisa.ia@ufv.br
**Telefone:** (31) 3612-3456
**Website:** www.ufv.br/editais/ia2024
