# Regulamento do Programa de Pós-Graduação em Ciência da Computação

**Instituição:** Universidade Federal de Viçosa
**Programa:** Mestrado e Doutorado em Ciência da Computação
**Código CAPES:** 31001017001P9
**Última atualização:** Janeiro de 2024

## Estrutura do Programa

### Mestrado Acadêmico
- Duração: 24 meses (prorrogável por até 6 meses)
- Créditos mínimos: 24 créditos em disciplinas + dissertação
- Proficiência em inglês: obrigatória

### Doutorado
- Duração: 48 meses (prorrogável por até 12 meses)
- Créditos mínimos: 36 créditos (incluindo mestrado) + tese
- Exame de qualificação: obrigatório até 24º mês
- Proficiência em inglês: obrigatória (nível avançado)

## Linhas de Pesquisa

1. **Inteligência Artificial e Aprendizado de Máquina**
   - Aprendizado profundo
   - Processamento de linguagem natural
   - Visão computacional

2. **Engenharia de Software e Sistemas**
   - Métodos ágeis
   - Arquitetura de software
   - DevOps e computação em nuvem

3. **Ciência de Dados e Big Data**
   - Mineração de dados
   - Análise de redes sociais
   - Visualização de informação

4. **Computação de Alto Desempenho**
   - Computação paralela
   - Computação distribuída
   - GPU computing

## Processo Seletivo 2024

### Calendário
- **Inscrições:** 10 a 30 de março de 2024
- **Prova escrita:** 15 de abril de 2024
- **Análise de currículo:** até 20 de abril de 2024
- **Entrevistas:** 22 a 26 de abril de 2024
- **Resultado final:** 3 de maio de 2024
- **Matrícula:** 13 a 17 de maio de 2024

### Vagas
- Mestrado: 20 vagas
- Doutorado: 10 vagas
- Reserva de vagas: 30% cotas (PPI e PcD)

### Requisitos de Inscrição

#### Mestrado
- Graduação em área relacionada
- Coeficiente de rendimento mínimo: 7,0
- Carta de motivação
- Projeto de pesquisa preliminar (3-5 páginas)
- Duas cartas de recomendação

#### Doutorado
- Mestrado em área relacionada
- Produção científica mínima: 1 publicação
- Projeto de pesquisa detalhado (8-12 páginas)
- Três cartas de recomendação
- Entrevista com potencial orientador

## Bolsas Disponíveis

### CAPES
- Valor: R$ 2.100,00 (mestrado) / R$ 3.300,00 (doutorado)
- Quantidade: 15 bolsas mestrado, 8 bolsas doutorado
- Dedicação exclusiva obrigatória

### CNPq
- Valor: R$ 2.100,00 (mestrado) / R$ 3.300,00 (doutorado)
- Quantidade: 5 bolsas mestrado, 2 bolsas doutorado
- Dedicação exclusiva obrigatória

## Requisitos para Titulação

### Mestrado
1. Integralizar créditos em disciplinas
2. Comprovar proficiência em inglês
3. Publicar ou ter aceito 1 artigo em conferência/periódico
4. Defender dissertação perante banca examinadora

### Doutorado
1. Integralizar créditos em disciplinas
2. Comprovar proficiência em inglês (nível avançado)
3. Ser aprovado em exame de qualificação
4. Publicar ou ter aceito 2 artigos (1 em periódico)
5. Defender tese perante banca examinadora

## Atividades Complementares Obrigatórias

- Participação em seminários de pesquisa (mensais)
- Apresentação de trabalho em evento científico
- Estágio docência (doutorado - obrigatório)
- Participação em bancas de TCC (recomendado)

## Infraestrutura Disponível

- Laboratórios especializados com GPUs de última geração
- Cluster de computação de alto desempenho
- Biblioteca com acesso a bases de dados internacionais
- Salas de estudo individuais para pós-graduandos
- Recursos para participação em eventos científicos

## Contato

**Coordenação:** Prof. Dr. Carlos Alberto Silva
**Email:** ppgcc@ufv.br
**Telefone:** (31) 3612-7890
**Website:** www.ppgcc.ufv.br
**Horário de atendimento:** Segunda a quinta, 14h às 17h
