# Programa de Bolsas de Extensão Universitária 2024

**Instituição:** UFV - Pró-Reitoria de Extensão
**Programa:** Bolsas de Extensão Comunitária
**Edital:** PROEX-2024-045
**Vigência:** Março a Dezembro de 2024

## Apresentação

O Programa de Bolsas de Extensão visa apoiar projetos que promovam a interação transformadora entre universidade e comunidade, contribuindo para o desenvolvimento social e transferência de conhecimento.

## Modalidades de Bolsa

### Bolsa Estudante
- Valor mensal: R$ 500,00
- Carga horária: 12 horas semanais
- Vagas disponíveis: 30 bolsas

### Bolsa Professor Coordenador
- Valor mensal: R$ 1.200,00
- Carga horária: 8 horas semanais
- Vagas disponíveis: 15 bolsas

## Áreas Prioritárias

1. Educação e inclusão social
2. Desenvolvimento rural sustentável
3. Saúde preventiva e bem-estar comunitário
4. Tecnologia social e inovação
5. Cultura e preservação do patrimônio

## Requisitos do Projeto

- Impacto social mensurável
- Envolvimento direto da comunidade
- Articulação entre ensino, pesquisa e extensão
- Sustentabilidade das ações
- Potencial de multiplicação

### Para Estudantes
- Estar regularmente matriculado em curso de graduação
- Ter cursado pelo menos 20% do curso
- Disponibilidade para dedicação às atividades
- Não acumular com outras bolsas

### Para Coordenadores
- Ser docente efetivo da UFV
- Experiência prévia em extensão (desejável)
- Capacidade de orientação e supervisão

## Cronograma

- **Inscrições:** 1º a 20 de fevereiro de 2024
- **Avaliação:** 21 de fevereiro a 5 de março de 2024
- **Resultado:** 8 de março de 2024
- **Início das atividades:** 15 de março de 2024

## Processo Seletivo

### Critérios de Avaliação (Projetos)
- Relevância social (30%)
- Viabilidade (25%)
- Metodologia participativa (20%)
- Equipe qualificada (15%)
- Sustentabilidade (10%)

### Documentação Obrigatória
1. Projeto detalhado (máximo 15 páginas)
2. Plano de trabalho semestral
3. Carta de apoio da comunidade beneficiária
4. Cronograma de atividades
5. Orçamento (se houver contrapartida)

## Obrigações dos Bolsistas

- Cumprir carga horária estabelecida
- Participar de reuniões de acompanhamento
- Registrar atividades no sistema SIGEXT
- Elaborar relatórios mensais e final
- Apresentar resultados em eventos de extensão

## Acompanhamento e Avaliação

- Reuniões mensais com coordenador
- Relatórios trimestrais
- Avaliação de impacto semestral
- Participação obrigatória na Semana de Extensão

## Informações Adicionais

As bolsas podem ser renovadas por até 12 meses, mediante avaliação positiva e disponibilidade orçamentária.

## Contato

**Coordenação:** Pró-Reitoria de Extensão
**Email:** bolsas.extensao@ufv.br
**Telefone:** (31) 3612-4567
**Atendimento:** Segunda a sexta, 8h às 18h
