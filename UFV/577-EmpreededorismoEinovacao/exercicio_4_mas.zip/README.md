# Sistema Multi-Agente para Geração de Relatórios

Sistema multi-agente que demonstra a criação e coordenação de agentes LLM para geração de relatórios baseados em documentos e pesquisa web.

## 🎯 Objetivo Educacional

Este projeto ilustra conceitos fundamentais de sistemas multi-agente:
- Criação de agentes especializados com LLMs
- Uso de ferramentas (tools) via function calling
- Comunicação hierárquica entre agentes
- Orquestração de tarefas complexas

## 🏗️ Arquitetura

### Agentes

1. **Gerente Coordenador** - Coordena a equipe e delega tarefas
2. **Arquivista de Documentos** - Busca informações na base de documentos
3. **Verificador de Fatos** - Valida informações via busca web
4. **Escritor de Relatórios** - Redige relatórios profissionais

### Ferramentas

- `delegar_tarefa` - Comunicação Manager → Workers
- `responder_gerente` - Comunicação Workers → Manager
- `buscar_documentos` - Busca BM25 em arquivos markdown
- `buscar_web` - Busca web via Tavily API

## 📋 Pré-requisitos

- Python 3.12+
- Poetry (gerenciador de dependências)
- Chaves API: OpenAI/Outro Provedor e Tavily

## 🚀 Instalação

### 1. Clone ou baixe o projeto

```bash
cd exercicio_4_mas
```

### 2. Instalar dependências com Poetry

```bash
poetry install
```

### 3. Configurar variáveis de ambiente

Copie o arquivo de exemplo e configure suas chaves:

```bash
cp .env.example .env
```

Edite `.env` e adicione suas chaves:

```bash
OPENAI_API_KEY=sua-chave-aqui
TAVILY_API_KEY=sua-chave-aqui
```

**Obter Chaves API:**
- OpenAI: https://platform.openai.com/api-keys
- Tavily: https://tavily.com (criar conta gratuita)

## 💻 Uso

### Executar o script principal

```bash
poetry run python scripts/executar.py gerar
```

O sistema solicitará uma consulta interativamente.

### Com consulta via argumento

```bash
poetry run python scripts/executar.py gerar --consulta "Crie um resumo do programa de bolsas de extensão"
```

### Salvar relatório em arquivo

```bash
poetry run python scripts/executar.py gerar --consulta "sua consulta" --salvar
```

### Ver exemplos de consultas

```bash
poetry run python scripts/executar.py exemplos
```

## 📚 Estrutura do Projeto

```
exercicio_4_mas/
├── config.py              # Configurações (Pydantic Settings)
├── modelos.py             # Modelos de dados (Pydantic)
├── ferramentas.py         # Implementação de ferramentas
├── agentes.py             # Definição dos agentes
├── sistema.py             # Orquestrador do sistema
├── base_documentos/       # Documentos para busca
│   ├── edital_pesquisa_ia_2024.md
│   ├── programa_bolsas_extensao.md
│   └── regulamento_pos_graduacao.md
├── scripts/
│   └── executar.py        # CLI com Rich/Typer
├── .env.example           # Exemplo de configuração
└── README.md              # Este arquivo
```

## 🔍 Como Funciona

### Exemplo de Fluxo de Execução

1. **Usuário** envia consulta
2. **Gerente** analisa e delega para **Arquivista**
3. **Arquivista** busca em documentos e responde
4. **Gerente** pode solicitar validação ao **Verificador**
5. **Verificador** busca na web e valida informações
6. **Gerente** delega redação ao **Escritor**
7. **Escritor** gera relatório formatado
8. **Gerente** retorna relatório final ao usuário

### Comunicação

- Todos os agentes se comunicam através do **Gerente** (hierárquico)
- Usa OpenAI Function Calling para ferramentas
- Thread compartilhada de mensagens
- Máximo de 30 iterações para evitar loops

## 📖 Conceitos Demonstrados

### 1. Agentes Especializados

Cada agente tem:
- Instruções específicas (system prompt)
- Ferramentas dedicadas
- Papel bem definido

### 2. Function Calling

Uso nativo de OpenAI function calling:
- Definição de ferramentas em JSON Schema
- Execução controlada de funções
- Retorno estruturado

### 3. Orquestração

- Gerenciamento de estado compartilhado
- Controle de fluxo entre agentes
- Tratamento de erros

### 4. RAG Simplificado

- Busca BM25 (sem embeddings)
- Chunking de documentos
- Ranking de relevância
