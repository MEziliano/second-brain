from pathlib import Path
from rank_bm25 import BM25Okapi
from tavily import TavilyClient
from config import settings
from modelos import ResultadoBusca


class GerenciadorFerramentas:
    """Gerencia todas as ferramentas disponíveis para os agentes"""

    def __init__(self):
        self.tavily_client = TavilyClient(
            api_key=settings.tavily_api_key.get_secret_value()
        )
        self._indice_bm25 = None
        self._documentos = []
        self._metadados = []
        self._carregar_documentos()

    def _carregar_documentos(self):
        """Carrega documentos markdown e cria índice BM25"""
        base_path = Path("base_documentos")
        if not base_path.exists():
            return

        for arquivo in base_path.glob("*.md"):
            with open(arquivo, "r", encoding="utf-8") as f:
                conteudo = f.read()

            chunks = self._dividir_em_chunks(conteudo)
            for chunk in chunks:
                self._documentos.append(chunk)
                self._metadados.append({"arquivo": arquivo.name})

        if self._documentos:
            corpus_tokenizado = [doc.lower().split() for doc in self._documentos]
            self._indice_bm25 = BM25Okapi(corpus_tokenizado)

    def _dividir_em_chunks(self, texto: str) -> list[str]:
        """Divide texto em chunks menores"""
        palavras = texto.split()
        chunk_size = settings.chunk_size_documentos // 5

        chunks = []
        for i in range(0, len(palavras), chunk_size):
            chunk = " ".join(palavras[i : i + chunk_size])
            if chunk.strip():
                chunks.append(chunk)

        return chunks if chunks else [texto]

    def buscar_documentos(self, consulta: str, max_resultados: int = 3) -> str:
        """Busca documentos usando BM25"""
        if not self._indice_bm25 or not self._documentos:
            return "Nenhum documento encontrado na base."

        consulta_tokenizada = consulta.lower().split()
        scores = self._indice_bm25.get_scores(consulta_tokenizada)

        resultados_indices = sorted(
            range(len(scores)), key=lambda i: scores[i], reverse=True
        )[:max_resultados]

        resultados = []
        for idx in resultados_indices:
            if scores[idx] > 0:
                resultado = ResultadoBusca(
                    texto=self._documentos[idx],
                    arquivo=self._metadados[idx]["arquivo"],
                    score=float(scores[idx]),
                )
                resultados.append(resultado)

        if not resultados:
            return "Nenhum resultado relevante encontrado."

        resposta = f"Encontrados {len(resultados)} resultado(s):\n\n"
        for i, r in enumerate(resultados, 1):
            resposta += f"[{i}] Arquivo: {r.arquivo} (Score: {r.score:.2f})\n"
            resposta += f"{r.texto[:300]}...\n\n"

        return resposta

    def buscar_web(self, consulta: str) -> str:
        """Busca informações na web usando Tavily"""
        try:
            resposta = self.tavily_client.search(
                query=consulta, max_results=3, search_depth="basic"
            )

            if not resposta.get("results"):
                return "Nenhum resultado encontrado na web."

            resultado_texto = f"Encontrados {len(resposta['results'])} resultado(s) na web:\n\n"
            for i, item in enumerate(resposta["results"], 1):
                resultado_texto += f"[{i}] {item.get('title', 'Sem título')}\n"
                resultado_texto += f"URL: {item.get('url', 'N/A')}\n"
                resultado_texto += f"{item.get('content', 'Sem conteúdo')[:300]}...\n\n"

            return resultado_texto

        except Exception as e:
            return f"Erro ao buscar na web: {str(e)}"


# Definições de ferramentas para OpenAI function calling
def obter_ferramenta_delegar_tarefa() -> dict:
    """Retorna definição da ferramenta delegar_tarefa"""
    return {
        "type": "function",
        "function": {
            "name": "delegar_tarefa",
            "description": "Delega uma tarefa para um agente especializado",
            "parameters": {
                "type": "object",
                "properties": {
                    "mensagem": {
                        "type": "string",
                        "description": "Descrição detalhada da tarefa",
                    },
                    "agente_destino": {
                        "type": "string",
                        "enum": [
                            "arquivista_documentos",
                            "verificador_fatos",
                            "escritor_relatorios",
                        ],
                        "description": "Nome do agente que executará a tarefa",
                    },
                },
                "required": ["mensagem", "agente_destino"],
            },
        },
    }


def obter_ferramenta_responder_gerente() -> dict:
    """Retorna definição da ferramenta responder_gerente"""
    return {
        "type": "function",
        "function": {
            "name": "responder_gerente",
            "description": "Envia resposta de volta ao gerente coordenador",
            "parameters": {
                "type": "object",
                "properties": {
                    "mensagem": {
                        "type": "string",
                        "description": "Resposta ou resultado da tarefa executada",
                    }
                },
                "required": ["mensagem"],
            },
        },
    }


def obter_ferramenta_buscar_documentos() -> dict:
    """Retorna definição da ferramenta buscar_documentos"""
    return {
        "type": "function",
        "function": {
            "name": "buscar_documentos",
            "description": "Busca informações em documentos da base de dados",
            "parameters": {
                "type": "object",
                "properties": {
                    "consulta": {
                        "type": "string",
                        "description": "Termo ou frase de busca",
                    },
                    "max_resultados": {
                        "type": "integer",
                        "description": "Número máximo de resultados (padrão: 3)",
                        "default": 3,
                    },
                },
                "required": ["consulta"],
            },
        },
    }


def obter_ferramenta_buscar_web() -> dict:
    """Retorna definição da ferramenta buscar_web"""
    return {
        "type": "function",
        "function": {
            "name": "buscar_web",
            "description": "Busca informações atualizadas na internet",
            "parameters": {
                "type": "object",
                "properties": {
                    "consulta": {
                        "type": "string",
                        "description": "Termo ou pergunta de busca",
                    }
                },
                "required": ["consulta"],
            },
        },
    }
